(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/snaptron.js                                                  //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by Phani on 2/9/2016.                                       //
 *                                                                     //
 * This file proves querying functions to get information from the snaptron server
 */                                                                    //
                                                                       //
var SNAPTRON_URL = "http://stingray.cs.jhu.edu:8443/snaptron";         // 7
var SAMPLE_URL = "http://stingray.cs.jhu.edu:8443/samples";            // 8
                                                                       //
SnapApp.Snaptron = {};                                                 // 10
                                                                       //
/**                                                                    //
 * Updates all of the regions in the query if they have                //
 * not been loaded, or if they expired.                                //
 * @param queryId                                                      //
 * @returns {*}                                                        //
 */                                                                    //
SnapApp.Snaptron.updateQuery = function (queryId) {                    // 18
    var query = SnapApp.QueryDB.getQuery(queryId);                     // 19
    if (query) {                                                       // 20
        var regionIds = query[QRY_REGIONS];                            // 21
        for (var i = 0; i < regionIds.length; i++) {                   // 22
            if (!SnapApp.RegionDB.hasRegion(regionIds[i])) {           // 23
                SnapApp.RegionDB.newRegion(regionIds[i]);              // 24
            }                                                          //
            var region = SnapApp.RegionDB.getRegion(regionIds[i]);     // 26
            if (region[REGION_LOADED_DATE] == null || new Date().getTime() - region[REGION_LOADED_DATE] > REGION_REFRESH_TIME) {
                updateRegion(region["_id"]);                           // 29
            }                                                          //
            loadMissingRegionJunctions(region["_id"]);                 // 31
        }                                                              //
        return queryId;                                                // 33
    }                                                                  //
    return null;                                                       // 35
};                                                                     //
                                                                       //
/**                                                                    //
 * Loads the missing samples for the given junctions and adds them to the db.
 * @param junctionIds                                                  //
 * @returns {*}                                                        //
 */                                                                    //
SnapApp.Snaptron.loadMissingJunctionSamples = function (junctionIds) {
    var junctions = SnapApp.JunctionDB.getJunctions(junctionIds);      // 44
    var sampleIds = _.uniq(_.flatten(_.pluck(junctions, JNCT_SAMPLES_KEY)));
    return SnapApp.Snaptron.loadMissingSamples(sampleIds);             // 46
};                                                                     //
                                                                       //
/**                                                                    //
 * Loads the given samples, if they have not already been loaded.      //
 * @param sampleIds                                                    //
 */                                                                    //
SnapApp.Snaptron.loadMissingSamples = function (sampleIds) {           // 53
    var samplesToLoad = _.filter(sampleIds, function (sampleId) {      // 54
        return !SnapApp.SampleDB.hasSample(sampleId);                  // 55
    });                                                                //
    if (samplesToLoad.length > 0) {                                    // 57
        console.log("Loading " + samplesToLoad.length + " samples");   // 58
        try {                                                          // 59
            var sampleQuery = "\"[{\"ids\":[\"" + samplesToLoad.join("\",\"") + "\"]}]\"";
            var params = { "fields": sampleQuery };                    // 61
            var responseTSV = Meteor.http.post(SAMPLE_URL, { params: params }).content.trim();
            var samples = SnapApp.Parser.parseSampleResponse(responseTSV);
            SnapApp.SampleDB.addSamples(samples);                      // 64
        } catch (err) {                                                //
            console.error("Error in loadMissingSamples");              // 66
            console.error(err);                                        // 67
            return null;                                               // 68
        }                                                              //
    }                                                                  //
    return sampleIds;                                                  // 71
};                                                                     //
                                                                       //
/**                                                                    //
 * Loads the metadata and junctions list for a given region.           //
 * If the region document doesn't exist, it will be created.           //
 * @param regionId                                                     //
 * @returns {*}                                                        //
 */                                                                    //
function updateRegion(regionId) {                                      // 81
    var snaptronQuery = SNAPTRON_URL + "?regions=" + regionId + "&contains=1&fields=snaptron_id";
    if (!SnapApp.RegionDB.hasRegion(regionId)) {                       // 83
        console.log("Region with id " + regionId + " doesn't exist, creating it.");
        if (SnapApp.RegionDB.newRegion(regionId) == null) {            // 85
            console.log("Failed to create a region document for " + regionId + "! Aborting update");
            return null;                                               // 87
        }                                                              //
    }                                                                  //
    try {                                                              // 90
        console.log("Loading region " + regionId + "...");             // 91
        var responseTSV = Meteor.http.get(SNAPTRON_URL + snaptronQuery).content.trim();
        var regionDoc = SnapApp.Parser.parseRegionResponse(regionId, responseTSV);
        SnapApp.RegionDB.upsertRegion(regionDoc);                      // 94
        return regionId;                                               // 95
    } catch (err) {                                                    //
        SnapApp.RegionDB.setRegionLoadedDate(regionId, null);          // 97
        console.error("Error in updateRegion (\"" + regionId + "\")!");
        console.error(err);                                            // 99
        return null;                                                   // 100
    }                                                                  //
}                                                                      //
                                                                       //
/**                                                                    //
 * Checks which junctions have already been loaded for the             //
 * given region (by ID), and attempts to load the rest                 //
 * @param regionId                                                     //
 * @returns {*} regionId on success, null on failure                   //
 */                                                                    //
function loadMissingRegionJunctions(regionId) {                        // 110
    var region = SnapApp.RegionDB.getRegion(regionId);                 // 111
    if (region == null) {                                              // 112
        console.error("loadMissingRegionJunctions called with an ID not found (\"" + regionId + "\")!");
        return;                                                        // 114
    }                                                                  //
    var regionJunctionIDs = region[REGION_JUNCTIONS];                  // 116
    var toLoadJunctionIDs = [];                                        // 117
    for (var i = 0; i < regionJunctionIDs.length; i++) {               // 118
        if (!SnapApp.JunctionDB.hasJunction(regionJunctionIDs[i])) {   // 119
            toLoadJunctionIDs.push(regionJunctionIDs[i]);              // 120
        }                                                              //
    }                                                                  //
    if (toLoadJunctionIDs.length > 0) {                                // 123
        console.log("Loading " + toLoadJunctionIDs.length + " junctions for region (\"" + regionId + "\")");
        try {                                                          // 125
            var snaptronQuery = "\"[{\"ids\":[\"" + toLoadJunctionIDs.join("\",\"") + "\"]}]\"";
            var params = { "fields": snaptronQuery };                  // 127
            var responseTSV = Meteor.http.post(SNAPTRON_URL, { params: params }).content.trim();
            var junctions = SnapApp.Parser.parseJunctionsResponse(responseTSV);
            SnapApp.JunctionDB.addJunctions(junctions);                // 130
            return regionId;                                           // 131
        } catch (err) {                                                //
            console.error("Error in loadMissingRegionJunctions with region " + regionId);
            console.error(err);                                        // 134
            return null;                                               // 135
        }                                                              //
    }                                                                  //
    return regionId;                                                   // 138
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=snaptron.js.map

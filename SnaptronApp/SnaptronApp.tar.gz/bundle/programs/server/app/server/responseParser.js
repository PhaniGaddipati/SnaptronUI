(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/responseParser.js                                            //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by Phani on 3/7/2016.                                       //
 */                                                                    //
                                                                       //
SnapApp.Parser = {};                                                   // 5
                                                                       //
/**                                                                    //
 * Parses the TSV response of a single region snaptron query           //
 * @param regionId                                                     //
 * @param responseTSV                                                  //
 * @returns {*} A document representing the parsed region              //
 */                                                                    //
SnapApp.Parser.parseRegionResponse = function (regionId, responseTSV) {
    check(responseTSV, String);                                        // 14
                                                                       //
    var regionDoc = {};                                                // 16
    regionDoc["_id"] = regionId;                                       // 17
    regionDoc[REGION_METADATA] = [];                                   // 18
                                                                       //
    var lines = responseTSV.split("\n");                               // 20
    var lineNum = 0;                                                   // 21
    //Parse metadata                                                   //
    for (var i = 0; i < lines.length; i++) {                           // 23
        if (lines[i].startsWith("##")) {                               // 24
            var str = lines[i].replace(/[#]+/g, "");                   // 25
            if (str.includes("=")) {                                   // 26
                var elems = str.split("=");                            // 27
                var info = {};                                         // 28
                info[elems[0]] = elems[1];                             // 29
                regionDoc[REGION_METADATA].push(info);                 // 30
            } else {                                                   //
                console.log("Unrecognized metadata line: " + str + ". Ignoring it.");
            }                                                          //
            lineNum++;                                                 // 34
        } else {                                                       //
            break;                                                     // 36
        }                                                              //
    }                                                                  //
                                                                       //
    // Find the column where the id is                                 //
    // Next line should be header                                      //
    var headerElems = lines[lineNum].replace("#", "").split("\t");     // 42
    var idCol = -1;                                                    // 43
    for (i = 0; i < headerElems.length; i++) {                         // 44
        if (headerElems[i] === JNCT_ID_FIELD) {                        // 45
            idCol = i;                                                 // 46
            break;                                                     // 47
        }                                                              //
    }                                                                  //
    if (idCol == -1) {                                                 // 50
        console.warn("ID column now found when trying to update region " + regionId + "!");
        return null;                                                   // 52
    }                                                                  //
    lineNum++;                                                         // 54
                                                                       //
    // Ignore type line if it exists, hardcoded for now                //
    if (lineNum < lines.length && lines[lineNum].startsWith("#")) {    // 57
        lineNum++;                                                     // 58
    }                                                                  //
                                                                       //
    // Get the junction IDs                                            //
    var junctionIds = [];                                              // 62
    for (var line = lineNum; line < lines.length; line++) {            // 63
        junctionIds.push(lines[line].split("\t")[idCol]);              // 64
    }                                                                  //
                                                                       //
    regionDoc[REGION_JUNCTIONS] = junctionIds;                         // 67
    regionDoc[REGION_LOADED_DATE] = new Date();                        // 68
                                                                       //
    return regionDoc;                                                  // 70
};                                                                     //
                                                                       //
/**                                                                    //
 * Parses the response for a junction request                          //
 * @param responseTSV                                                  //
 * @returns {Array} An array of the parsed junctions                   //
 */                                                                    //
SnapApp.Parser.parseJunctionsResponse = function (responseTSV) {       // 78
    check(responseTSV, String);                                        // 79
    // Get rid of commented lines                                      //
    responseTSV.replace(/[#].+/g, "");                                 // 81
                                                                       //
    var lines = responseTSV.split("\n");                               // 83
    var headers = lines[0].split("\t");                                // 84
    _.each(headers, function (val, index) {                            // 85
        //'.' and '$' not supported as keys in Mongo, replace with '_'
        headers[index] = val.replace(".", "_").replace("$", "_");      // 87
    });                                                                //
    var junctions = [];                                                // 89
                                                                       //
    // Line 1 is data types, ignoring it for now, it's hardcoded       //
                                                                       //
    for (var i = 2; i < lines.length; i++) {                           // 93
        if (lines[i] && 0 != lines[i].length) {                        // 94
            var elems = lines[i].split("\t");                          // 95
            var junctionDoc = {};                                      // 96
                                                                       //
            for (var col = 0; col < elems.length; col++) {             // 98
                if (headers[col] == JNCT_ID_FIELD) {                   // 99
                    junctionDoc["_id"] = elems[col];                   // 100
                } else {                                               //
                    junctionDoc[headers[col]] = castMember(elems[col], JNCT_COL_TYPES[headers[col]]);
                }                                                      //
            }                                                          //
                                                                       //
            junctions.push(junctionDoc);                               // 106
        }                                                              //
    }                                                                  //
                                                                       //
    return junctions;                                                  // 110
};                                                                     //
                                                                       //
/**                                                                    //
 * Parses the response for a samples request                           //
 * @param responseTSV                                                  //
 * @returns {Array} An array of the parsed samples                     //
 */                                                                    //
SnapApp.Parser.parseSampleResponse = function (responseTSV) {          // 118
    check(responseTSV, String);                                        // 119
    // Get rid of commented lines                                      //
    responseTSV.replace(/[#].+/g, "");                                 // 121
                                                                       //
    var lines = responseTSV.split("\n");                               // 123
    var headers = lines[0].split("\t");                                // 124
    _.each(headers, function (val, index) {                            // 125
        //'.' and '$' not supported as keys in Mongo, replace with '_'
        headers[index] = val.replace(".", "_").replace("$", "_");      // 127
    });                                                                //
    var samples = [];                                                  // 129
                                                                       //
    for (var i = 1; i < lines.length; i++) {                           // 131
        if (lines[i] && 0 != lines[i].length) {                        // 132
            var elems = lines[i].split("\t");                          // 133
            var sampleDoc = {};                                        // 134
                                                                       //
            for (var col = 0; col < elems.length; col++) {             // 136
                if (headers[col] == SAMPLE_ID_FIELD) {                 // 137
                    sampleDoc["_id"] = elems[col];                     // 138
                } else {                                               //
                    sampleDoc[headers[col]] = elems[col];              // 140
                }                                                      //
            }                                                          //
                                                                       //
            samples.push(sampleDoc);                                   // 144
        }                                                              //
    }                                                                  //
                                                                       //
    return samples;                                                    // 148
};                                                                     //
                                                                       //
function castMember(toCast, type) {                                    // 151
    check(type, String);                                               // 152
    switch (type) {                                                    // 153
        case "str[]":                                                  // 154
            return String(toCast).split(",");                          // 155
        case "float[]":                                                // 156
            var elems = String(toCast).split(",");                     // 157
            var floats = [];                                           // 158
            for (var i = 0; i < elems.length; i++) {                   // 159
                floats.push(parseFloat(elems[i]));                     // 160
            }                                                          //
            return floats;                                             // 162
        case "str":                                                    // 162
            return String(toCast);                                     // 164
        case "int":                                                    // 164
            return parseInt(toCast);                                   // 166
        case "bool":                                                   // 166
            return parseInt(toCast) != 0;                              // 168
        case "float":                                                  // 168
            return parseFloat(toCast);                                 // 170
    }                                                                  // 170
}                                                                      //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=responseParser.js.map

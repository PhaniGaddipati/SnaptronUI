(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// server/publications.js                                              //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
/**                                                                    //
 * Created by Phani on 2/13/2016.                                      //
 */                                                                    //
                                                                       //
/**                                                                    //
 * Updates the query and publishes it. Publishes nothing               //
 * on updating error.                                                  //
 */                                                                    //
Meteor.publish("queries", function (queryId) {                         // 9
    check(queryId, String);                                            // 10
                                                                       //
    if (SnapApp.Snaptron.updateQuery(queryId) == null) {               // 12
        // Failed                                                      //
        return [];                                                     // 14
    }                                                                  //
                                                                       //
    console.log("Published query " + queryId);                         // 17
    return SnapApp.QueryDB.findQuery(queryId);                         // 18
});                                                                    //
                                                                       //
/**                                                                    //
 * Publishes the regions relevant to the given query ID.               //
 */                                                                    //
Meteor.publish("regions", function (queryId) {                         // 24
    check(queryId, String);                                            // 25
                                                                       //
    var regions = SnapApp.RegionDB.findRegionsForQuery(queryId);       // 27
    if (regions == null) {                                             // 28
        return [];                                                     // 29
    }                                                                  //
    console.log("Published " + regions.count() + " regions for query " + queryId);
    return regions;                                                    // 32
});                                                                    //
                                                                       //
/**                                                                    //
 * Publishes the junctions relevant to the given query ID.             //
 */                                                                    //
Meteor.publish("junctions", function (queryId) {                       // 38
    check(queryId, String);                                            // 39
                                                                       //
    var junctions = SnapApp.JunctionDB.findJunctionsForQuery(queryId);
    if (junctions == null) {                                           // 42
        return [];                                                     // 43
    }                                                                  //
    console.log("Published " + junctions.count() + " junctions for query " + queryId);
    return junctions;                                                  // 46
});                                                                    //
                                                                       //
/**                                                                    //
 * Publishes samples that a part of the given junctions by ID.         //
 */                                                                    //
Meteor.publish("samplesForJunctions", function (junctionIds, limit) {  // 52
    check(junctionIds, [String]);                                      // 53
    check(limit, Number);                                              // 54
                                                                       //
    SnapApp.Snaptron.loadMissingJunctionSamples(junctionIds);          // 56
    var junctions = SnapApp.JunctionDB.getJunctions(junctionIds);      // 57
    var sampleIds = _.flatten(_.pluck(junctions, JNCT_SAMPLES_KEY));   // 58
    var samples = Samples.find({                                       // 59
        "_id": {                                                       // 60
            "$in": sampleIds                                           // 61
        }                                                              //
    }, {                                                               //
        limit: limit                                                   // 64
    });                                                                //
    console.log("Published " + Math.min(samples.count(), limit) + " samples for " + junctionIds.length + " junctions");
    return samples;                                                    // 67
});                                                                    //
/**                                                                    //
 * Publishes the elements relevant to a processor. The publishing is delegated
 * to the processor's publishFunction as defined in the index.         //
 */                                                                    //
Meteor.publish("processorElements", function (queryId, processorId) {  // 73
    check(queryId, String);                                            // 74
    check(processorId, String);                                        // 75
                                                                       //
    var processor = SnapApp.QueryDB.getProcessorFromQuery(queryId, processorId);
    if (!processor) {                                                  // 78
        return [];                                                     // 79
    }                                                                  //
    var index = SnapApp.Processors.Index[processor[QRY_PROCESSOR_TYPE]];
    if (index[SnapApp.Processors.PUBLISH_FUNCTION] == null) {          // 82
        // Nothing to publish                                          //
        return [];                                                     // 84
    }                                                                  //
    console.log("Delegating publishing of processorElements for " + processorId);
    return index[SnapApp.Processors.PUBLISH_FUNCTION](processor);      // 87
});                                                                    //
                                                                       //
/**                                                                    //
 * Publishes additional user information.                              //
 */                                                                    //
Meteor.publish("userData", function () {                               // 93
    if (this.userId) {                                                 // 94
        var fields = {};                                               // 95
        fields[USER_QRYS] = 1;                                         // 96
        fields[USER_STARRED_QRYS] = 1;                                 // 97
        return Users.find({ _id: this.userId }, { fields: fields });   // 98
    } else {                                                           //
        this.ready();                                                  // 100
    }                                                                  //
});                                                                    //
                                                                       //
/**                                                                    //
 * Publishes queries and regions for the purposes of the account page.
 * All queries relevant to the user are published, as well as all of the
 * regions that are a part of these queries.                           //
 *                                                                     //
 * The following fields are NOT published to minimized data:           //
 *      QRY_FILTERS, QRY_GROUPS, QRY_PROCESSORS,                       //
 *      REGION_JUNCTIONS                                               //
 */                                                                    //
Meteor.publish("userQueriesAndRegions", function () {                  // 113
    if (this.userId) {                                                 // 114
        var queries = _.union(SnapApp.UserDB.getUserQueryIds(this.userId), SnapApp.UserDB.getUserStarredQueryIds(this.userId));
        var qrySelector = {                                            // 117
            "_id": { "$in": queries }                                  // 118
        };                                                             //
        var qryFields = {};                                            // 120
                                                                       //
        qryFields[QRY_FILTERS] = 0;                                    // 122
        qryFields[QRY_GROUPS] = 0;                                     // 123
        qryFields[QRY_PROCESSORS] = 0;                                 // 124
        var queryCursor = Queries.find(qrySelector, { fields: qryFields });
                                                                       //
        var regions = _.flatten(_.pluck(queryCursor.fetch(), QRY_REGIONS));
        var regionSelector = {                                         // 128
            "_id": { "$in": regions }                                  // 129
        };                                                             //
        var regionFields = {};                                         // 131
        regionFields[REGION_JUNCTIONS] = 0;                            // 132
                                                                       //
        return [queryCursor, Regions.find(regionSelector, { fields: regionFields })];
    } else {                                                           //
        this.ready();                                                  // 136
    }                                                                  //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=publications.js.map
